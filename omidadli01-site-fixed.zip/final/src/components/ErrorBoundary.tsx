import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
}

// Catches any rendering/runtime error anywhere below it in the tree and shows
// a friendly, dismissable recovery screen instead of leaving the visitor
// looking at an empty colored page with no explanation and no way forward.
export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: unknown, info: unknown) {
    // eslint-disable-next-line no-console
    console.error('App crashed:', error, info);
  }

  handleReload = () => {
    try {
      // Best-effort: clear the local content cache in case corrupted/stale
      // cached data is what caused the crash, then hard-reload.
      localStorage.removeItem('OMID_ADLI_SITE_CONTENT_V3');
    } catch (e) {
      // ignore
    }
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div
          dir="rtl"
          style={{
            minHeight: '100vh',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '1rem',
            padding: '2rem',
            textAlign: 'center',
            background: '#0f0a2e',
            color: '#eae6ff',
            fontFamily: "'Vazirmatn', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
          }}
        >
          <h1 style={{ fontSize: '1.25rem', fontWeight: 700, margin: 0 }}>
            مشکلی در نمایش صفحه پیش اومد
          </h1>
          <p style={{ opacity: 0.75, maxWidth: 420, margin: 0, fontSize: '0.95rem' }}>
            لطفاً صفحه رو دوباره بارگذاری کنید. اگه مشکل ادامه داشت، مرورگر یا نسخه سیستم‌عاملتون رو به‌روزرسانی کنید.
          </p>
          <button
            onClick={this.handleReload}
            style={{
              marginTop: '0.5rem',
              padding: '0.65rem 1.5rem',
              borderRadius: '999px',
              border: 'none',
              background: 'linear-gradient(135deg, #1d4ed8 0%, #2563eb 50%, #3b82f6 100%)',
              color: '#fff',
              fontWeight: 600,
              fontSize: '0.95rem',
              cursor: 'pointer',
            }}
          >
            بارگذاری مجدد صفحه
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
